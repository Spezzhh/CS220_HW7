import fetch from "../include/fetch.js";
import { URL } from "url";
export function fetchCurrentTemperature(coords) {
    // TODO
    function makeSearchURL(latQuery, longQuery) {
        // Construct a new URL object using the resource URL
        const searchURL = new URL(" https://220.maxkuechen.com/currentTemperature/forecast?");
        searchURL.searchParams.append("latitude", latQuery);
        searchURL.searchParams.append("longitude", longQuery);
        searchURL.searchParams.append("hourly", "temperature_2m");
        searchURL.searchParams.append("temperature_unit", "fahrenheit");
        return searchURL.toString();
    }
    return fetch(makeSearchURL(String(coords.lat), String(coords.lon)))
        .then((response) => (response.ok ? response.json() : Promise.reject(new Error(response.statusText))))
        .then((data) => {
        const time = data.hourly.time;
        const temperature_2m = data.hourly.temperature_2m;
        return { time, temperature_2m };
    });
}
//# sourceMappingURL=fetchCurrentTemperature.js.map