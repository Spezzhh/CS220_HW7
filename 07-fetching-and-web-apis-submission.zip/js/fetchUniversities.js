export function fetchUniversities(query) {
    // TODO
    return new Promise(res => res([]));
}
//# sourceMappingURL=fetchUniversities.js.map