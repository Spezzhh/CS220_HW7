export function fetchGeoCoord(query) {
    // TODO
    return new Promise(res => res({ lat: NaN, lon: NaN }));
}
//# sourceMappingURL=fetchGeoCoord.js.map